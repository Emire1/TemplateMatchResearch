from browsers_detector.browsers_detector import *
from browsers_detector.data import *
